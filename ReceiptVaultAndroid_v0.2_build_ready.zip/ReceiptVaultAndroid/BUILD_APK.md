# Build Receipt Vault APK

The project includes a GitHub Actions workflow at `.github/workflows/build-apk.yml`.

## Automatic build on GitHub
1. Create a GitHub repository and upload this project.
2. Push to `main` or `master`, or run **Actions > Build Receipt Vault APK > Run workflow**.
3. When the workflow finishes, download the artifact named `ReceiptVault-debug-apk`.
4. Inside it is `app-debug.apk`.

The workflow installs Android SDK 35, uses Java 17 + Gradle 8.9, runs unit tests, and builds the debug APK.

## Local build in Android Studio
Open the project folder in Android Studio and choose **Build > Build APK(s)**.

## Google Drive note
Google Drive backup uses the `drive.appdata` scope. On a real phone, Google authorization must be granted by the user. The app stores backup archives inside the app-specific Google Drive application-data space.
