package com.adam.receiptvault;

import android.app.Activity;
import android.content.Context;

import com.google.android.gms.auth.api.identity.AuthorizationRequest;
import com.google.android.gms.auth.api.identity.AuthorizationResult;
import com.google.android.gms.auth.api.identity.Identity;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.tasks.Task;

import java.util.Collections;

public final class DriveAuth {
    public static final String DRIVE_APPDATA = "https://www.googleapis.com/auth/drive.appdata";
    private DriveAuth() {}

    public static AuthorizationRequest request() {
        return AuthorizationRequest.builder()
                .setRequestedScopes(Collections.singletonList(new Scope(DRIVE_APPDATA)))
                .build();
    }

    public static Task<AuthorizationResult> authorize(Activity activity) {
        return Identity.getAuthorizationClient(activity).authorize(request());
    }

    public static Task<AuthorizationResult> authorize(Context context) {
        return Identity.getAuthorizationClient(context).authorize(request());
    }
}
