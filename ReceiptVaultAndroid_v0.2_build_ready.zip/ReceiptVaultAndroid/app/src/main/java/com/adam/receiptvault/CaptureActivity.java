package com.adam.receiptvault;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.ImageCapture;
import androidx.camera.core.ImageCaptureException;
import androidx.camera.core.Preview;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.view.PreviewView;
import androidx.core.content.ContextCompat;

import com.google.common.util.concurrent.ListenableFuture;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class CaptureActivity extends AppCompatActivity {
    private PreviewView previewView;
    private ImageCapture imageCapture;
    private ExecutorService cameraExecutor;
    private Button captureButton;
    private ProgressBar progress;

    private final ActivityResultLauncher<String> cameraPermission = registerForActivityResult(
            new ActivityResultContracts.RequestPermission(), granted -> {
                if (granted) startCamera(); else Toast.makeText(this, "لازم تسمح للكاميرا حتى نصور الوصل", Toast.LENGTH_LONG).show();
            });

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_capture);
        previewView = findViewById(R.id.previewView);
        captureButton = findViewById(R.id.btnCapture);
        progress = findViewById(R.id.progress);
        cameraExecutor = Executors.newSingleThreadExecutor();
        captureButton.setOnClickListener(v -> takePhoto());

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) startCamera();
        else cameraPermission.launch(Manifest.permission.CAMERA);
    }

    private void startCamera() {
        ListenableFuture<ProcessCameraProvider> future = ProcessCameraProvider.getInstance(this);
        future.addListener(() -> {
            try {
                ProcessCameraProvider provider = future.get();
                Preview preview = new Preview.Builder().build();
                preview.setSurfaceProvider(previewView.getSurfaceProvider());
                imageCapture = new ImageCapture.Builder().setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY).build();
                provider.unbindAll();
                provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, preview, imageCapture);
            } catch (Exception e) {
                Toast.makeText(this, "تعذر تشغيل الكاميرا: " + e.getMessage(), Toast.LENGTH_LONG).show();
            }
        }, ContextCompat.getMainExecutor(this));
    }

    private void takePhoto() {
        if (imageCapture == null) return;
        captureButton.setEnabled(false);
        progress.setVisibility(View.VISIBLE);
        File dir = new File(getFilesDir(), "receipts");
        if (!dir.exists()) dir.mkdirs();
        String stamp = new SimpleDateFormat("yyyyMMdd_HHmmss_SSS", Locale.US).format(new Date());
        File photo = new File(dir, "receipt_" + stamp + ".jpg");
        ImageCapture.OutputFileOptions options = new ImageCapture.OutputFileOptions.Builder(photo).build();
        imageCapture.takePicture(options, cameraExecutor, new ImageCapture.OnImageSavedCallback() {
            @Override public void onImageSaved(ImageCapture.OutputFileResults outputFileResults) { runOcr(photo); }
            @Override public void onError(ImageCaptureException exception) {
                runOnUiThread(() -> {
                    progress.setVisibility(View.GONE); captureButton.setEnabled(true);
                    Toast.makeText(CaptureActivity.this, "فشل التصوير: " + exception.getMessage(), Toast.LENGTH_LONG).show();
                });
            }
        });
    }

    private void runOcr(File photo) {
        try {
            InputImage image = InputImage.fromFilePath(this, Uri.fromFile(photo));
            TextRecognizer recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
            recognizer.process(image)
                    .addOnSuccessListener(text -> openReview(photo, text.getText()))
                    .addOnFailureListener(e -> openReview(photo, ""))
                    .addOnCompleteListener(task -> recognizer.close());
        } catch (Exception e) {
            openReview(photo, "");
        }
    }

    private void openReview(File photo, String rawText) {
        Receipt parsed = ReceiptParser.parse(rawText);
        runOnUiThread(() -> {
            Intent i = new Intent(this, ReceiptReviewActivity.class);
            i.putExtra("image_path", photo.getAbsolutePath());
            i.putExtra("raw_text", rawText);
            i.putExtra("merchant", parsed.merchant);
            i.putExtra("date", parsed.date);
            i.putExtra("total", parsed.total);
            i.putExtra("tax", parsed.tax);
            i.putExtra("category", parsed.category);
            i.putExtra("invoice", parsed.invoice);
            i.putExtra("payment", parsed.paymentMethod);
            i.putExtra("address", parsed.address);
            i.putExtra("gallons", parsed.gallons);
            i.putExtra("unit_price", parsed.unitPrice);
            startActivity(i);
            finish();
        });
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        if (cameraExecutor != null) cameraExecutor.shutdown();
    }
}
