package com.adam.receiptvault;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class ReceiptParser {
    private ReceiptParser() {}

    private static final Pattern MONEY = Pattern.compile("(?<!\\d)(?:[$€£]?\\s*)?([0-9]{1,6}(?:,[0-9]{3})*(?:\\.[0-9]{2,3})?)(?!\\d)");
    private static final Pattern DATE = Pattern.compile("\\b((?:0?[1-9]|1[0-2])[/-](?:0?[1-9]|[12]\\d|3[01])[/-](?:20)?\\d{2}|(?:20)\\d{2}[/-](?:0?[1-9]|1[0-2])[/-](?:0?[1-9]|[12]\\d|3[01]))\\b");
    private static final Pattern INVOICE = Pattern.compile("(?i)(?:invoice|inv|receipt|ticket|order|transaction|trans|ref|reference)\\s*(?:#|no\\.?|number)?\\s*[:#-]?\\s*([A-Z0-9-]{3,30})");
    private static final Pattern GALLONS = Pattern.compile("(?i)([0-9]{1,4}(?:\\.[0-9]{1,3})?)\\s*(?:gal|gallons?|gals?)\\b");
    private static final Pattern PRICE_PER = Pattern.compile("(?i)(?:price\\s*/?\\s*gal|price\\s*per\\s*gal|ppu|unit\\s*price|price)\\s*[:$ ]*([0-9]{1,2}\\.[0-9]{2,4})");

    public static Receipt parse(String rawText) {
        Receipt r = new Receipt();
        r.rawText = rawText == null ? "" : rawText;
        String normalized = r.rawText.replace('\r', '\n');
        String[] rawLines = normalized.split("\\n+");
        List<String> lines = new ArrayList<>();
        for (String line : rawLines) {
            String s = line.trim().replaceAll("\\s+", " ");
            if (!s.isEmpty()) lines.add(s);
        }

        r.merchant = findMerchant(lines);
        r.date = findDate(lines);
        r.total = findLabeledAmount(lines, Arrays.asList("grand total", "amount due", "total due", "total", "balance due", "amount"));
        if (r.total <= 0) r.total = findLargestLikelyAmount(lines);
        r.tax = findLabeledAmount(lines, Arrays.asList("sales tax", "tax", "vat"));
        r.invoice = findPattern(INVOICE, normalized);
        r.paymentMethod = findPaymentMethod(normalized);
        r.address = findAddress(lines);
        r.category = classify(normalized);
        r.gallons = findNumberPattern(GALLONS, normalized);
        r.unitPrice = findNumberPattern(PRICE_PER, normalized);

        if (r.gallons <= 0 && r.category.equals("ديزل / وقود")) {
            r.gallons = findFuelQuantity(lines);
        }
        if (r.unitPrice <= 0 && r.category.equals("ديزل / وقود")) {
            r.unitPrice = findFuelUnitPrice(lines, r.total, r.gallons);
        }
        return r;
    }

    private static String findMerchant(List<String> lines) {
        for (int i = 0; i < Math.min(lines.size(), 8); i++) {
            String s = lines.get(i);
            String l = s.toLowerCase(Locale.US);
            if (s.length() < 2 || s.length() > 70) continue;
            if (DATE.matcher(s).find()) continue;
            if (l.contains("receipt") || l.contains("invoice") || l.contains("thank you") || l.contains("welcome") || l.contains("www.") || l.contains("http")) continue;
            if (s.matches(".*\\d{3,}.*") && !s.matches(".*[A-Za-z].*")) continue;
            if (s.matches(".*[A-Za-z]{2,}.*")) return s;
        }
        return lines.isEmpty() ? "" : lines.get(0);
    }

    private static String findDate(List<String> lines) {
        for (String s : lines) {
            Matcher m = DATE.matcher(s);
            if (m.find()) return m.group(1);
        }
        return "";
    }

    private static double findLabeledAmount(List<String> lines, List<String> labels) {
        for (String label : labels) {
            for (String s : lines) {
                String l = s.toLowerCase(Locale.US);
                if (!l.contains(label)) continue;
                List<Double> amounts = extractAmounts(s);
                if (!amounts.isEmpty()) return amounts.get(amounts.size() - 1);
            }
        }
        return 0.0;
    }

    private static double findLargestLikelyAmount(List<String> lines) {
        double best = 0.0;
        for (String s : lines) {
            String l = s.toLowerCase(Locale.US);
            if (l.contains("phone") || l.contains("tel") || l.contains("zip") || l.contains("change")) continue;
            for (double v : extractAmounts(s)) {
                if (v > best && v < 100000) best = v;
            }
        }
        return best;
    }

    private static List<Double> extractAmounts(String line) {
        List<Double> values = new ArrayList<>();
        Matcher m = MONEY.matcher(line);
        while (m.find()) {
            try {
                values.add(Double.parseDouble(m.group(1).replace(",", "")));
            } catch (NumberFormatException ignored) {}
        }
        return values;
    }

    private static String findPattern(Pattern pattern, String text) {
        Matcher m = pattern.matcher(text);
        return m.find() ? m.group(1).trim() : "";
    }

    private static double findNumberPattern(Pattern pattern, String text) {
        Matcher m = pattern.matcher(text);
        if (!m.find()) return 0.0;
        try { return Double.parseDouble(m.group(1)); }
        catch (Exception e) { return 0.0; }
    }

    private static String findPaymentMethod(String text) {
        String l = text.toLowerCase(Locale.US);
        if (l.contains("visa")) return "Visa";
        if (l.contains("mastercard") || l.contains("master card")) return "Mastercard";
        if (l.contains("american express") || l.contains("amex")) return "Amex";
        if (l.contains("discover")) return "Discover";
        if (l.contains("debit")) return "Debit Card";
        if (l.contains("credit")) return "Credit Card";
        if (l.contains("cash")) return "Cash";
        if (l.contains("check") || l.contains("cheque")) return "Check";
        return "";
    }

    private static String findAddress(List<String> lines) {
        Pattern street = Pattern.compile("(?i)\\b\\d{1,6}\\s+[A-Za-z0-9 .'-]+\\s(?:st|street|rd|road|ave|avenue|blvd|boulevard|dr|drive|ln|lane|hwy|highway|ct|court|pkwy|parkway)\\b.*");
        for (String s : lines) {
            if (street.matcher(s).find()) return s;
        }
        return "";
    }

    public static String classify(String text) {
        String l = text == null ? "" : text.toLowerCase(Locale.US);
        if (containsAny(l, "diesel", "fuel", "gallon", "gallons", "truck stop", "pump", "def ")) return "ديزل / وقود";
        if (containsAny(l, "repair", "service", "labor", "mechanic", "alignment", "oil change", "diagnostic", "towing", "tow ")) return "صيانة / تصليح";
        if (containsAny(l, "auto parts", "truck parts", "part no", "part #", "napa", "autozone", "oreilly", "o'reilly")) return "قطع غيار";
        if (containsAny(l, "toll", "turnpike", "ezpass", "e-zpass", "tollway")) return "Toll / رسوم طريق";
        if (containsAny(l, "insurance", "policy", "premium")) return "تأمين";
        if (containsAny(l, "parking", "garage", "meter")) return "مواقف";
        if (containsAny(l, "hotel", "motel", "inn ", "lodging")) return "فندق / سكن";
        if (containsAny(l, "restaurant", "cafe", "coffee", "burger", "pizza", "food", "diner", "mcdonald", "subway")) return "طعام";
        if (containsAny(l, "payment", "paid", "deposit", "transfer")) return "دفعة / مدفوعات";
        if (containsAny(l, "walmart", "target", "home depot", "lowe's", "lowes", "supplies", "hardware")) return "مستلزمات";
        return "أخرى";
    }

    private static boolean containsAny(String text, String... needles) {
        for (String n : needles) if (text.contains(n)) return true;
        return false;
    }

    private static double findFuelQuantity(List<String> lines) {
        for (String s : lines) {
            String l = s.toLowerCase(Locale.US);
            if (l.contains("qty") || l.contains("quantity") || l.contains("gallon")) {
                for (double v : extractAmounts(s)) if (v > 0.1 && v < 1000) return v;
            }
        }
        return 0.0;
    }

    private static double findFuelUnitPrice(List<String> lines, double total, double gallons) {
        if (total > 0 && gallons > 0) {
            double p = total / gallons;
            if (p > 1 && p < 20) return Math.round(p * 1000.0) / 1000.0;
        }
        for (String s : lines) {
            String l = s.toLowerCase(Locale.US);
            if (l.contains("price") || l.contains("ppu") || l.contains("$/gal")) {
                for (double v : extractAmounts(s)) if (v > 1 && v < 20) return v;
            }
        }
        return 0.0;
    }
}
