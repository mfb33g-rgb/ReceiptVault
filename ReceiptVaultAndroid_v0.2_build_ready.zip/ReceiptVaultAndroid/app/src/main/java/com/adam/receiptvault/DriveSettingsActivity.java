package com.adam.receiptvault;

import android.app.PendingIntent;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.IntentSenderRequest;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.auth.api.identity.AuthorizationResult;
import com.google.android.gms.auth.api.identity.Identity;

import java.io.File;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class DriveSettingsActivity extends AppCompatActivity {
    private enum Action { CONNECT, BACKUP, RESTORE }
    private Action pendingAction = Action.CONNECT;
    private TextView status;
    private final ExecutorService io = Executors.newSingleThreadExecutor();

    private final ActivityResultLauncher<IntentSenderRequest> authorizationLauncher = registerForActivityResult(
            new ActivityResultContracts.StartIntentSenderForResult(), result -> {
                if (result.getResultCode() != RESULT_OK || result.getData() == null) {
                    toast("لم يتم منح صلاحية Google Drive"); return;
                }
                try {
                    AuthorizationResult auth = Identity.getAuthorizationClient(this).getAuthorizationResultFromIntent(result.getData());
                    onAuthorized(auth);
                } catch (Exception e) { toast("تعذر ربط Google Drive: " + e.getMessage()); }
            });

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_drive_settings);
        status = findViewById(R.id.txtDriveStatus);
        Button connect=findViewById(R.id.btnConnectDrive), backup=findViewById(R.id.btnBackupNow), restore=findViewById(R.id.btnRestore);
        connect.setOnClickListener(v -> requestAuthorization(Action.CONNECT));
        backup.setOnClickListener(v -> requestAuthorization(Action.BACKUP));
        restore.setOnClickListener(v -> new AlertDialog.Builder(this)
                .setTitle("استعادة آخر نسخة")
                .setMessage("سيتم استبدال قائمة الوصولات الحالية بآخر نسخة محفوظة على Google Drive. هل تريد المتابعة؟")
                .setNegativeButton("إلغاء", null)
                .setPositiveButton("استعادة", (d,w) -> requestAuthorization(Action.RESTORE)).show());
        refreshStatus();
    }

    private void requestAuthorization(Action action) {
        pendingAction = action;
        status.setText("جاري الاتصال بـ Google Drive…");
        DriveAuth.authorize(this)
                .addOnSuccessListener(auth -> {
                    if (auth.hasResolution()) {
                        PendingIntent pi = auth.getPendingIntent();
                        if (pi == null) { toast("تعذر فتح شاشة Google"); return; }
                        authorizationLauncher.launch(new IntentSenderRequest.Builder(pi.getIntentSender()).build());
                    } else onAuthorized(auth);
                })
                .addOnFailureListener(e -> toast("تعذر الاتصال بـ Google Drive: " + e.getMessage()));
    }

    private void onAuthorized(AuthorizationResult auth) {
        String token = auth.getAccessToken();
        if (token == null || token.isEmpty()) { toast("لم نحصل على صلاحية Google Drive"); return; }
        AutoBackup.setEnabled(this, true);
        AutoBackup.scheduleDaily(this);
        if (pendingAction == Action.CONNECT) {
            status.setText("متصل بـ Google Drive — النسخ التلقائي مفعّل");
            toast("تم ربط Google Drive");
        } else if (pendingAction == Action.BACKUP) {
            backupNow(token);
        } else {
            restoreLatest(token);
        }
    }

    private void backupNow(String token) {
        status.setText("جاري إنشاء ورفع النسخة الاحتياطية…");
        io.execute(() -> {
            try {
                File zip = BackupArchive.create(this);
                GoogleDriveClient.uploadBackup(token, zip);
                GoogleDriveClient.keepLatest(token, 10);
                runOnUiThread(() -> { status.setText("تم رفع النسخة الاحتياطية بنجاح"); toast("تم النسخ الاحتياطي"); });
            } catch (Exception e) { runOnUiThread(() -> toast("فشل النسخ: " + e.getMessage())); }
        });
    }

    private void restoreLatest(String token) {
        status.setText("جاري تنزيل آخر نسخة…");
        io.execute(() -> {
            try {
                GoogleDriveClient.DriveFile f = GoogleDriveClient.latestBackup(token);
                if (f == null) { runOnUiThread(() -> toast("لا توجد نسخة احتياطية محفوظة")); return; }
                File target = new File(getCacheDir(), "restore_latest.zip");
                GoogleDriveClient.download(token, f, target);
                BackupArchive.restore(this, target);
                runOnUiThread(() -> { status.setText("تمت الاستعادة من " + f.name); toast("تمت استعادة الوصولات"); });
            } catch (Exception e) { runOnUiThread(() -> toast("فشلت الاستعادة: " + e.getMessage())); }
        });
    }

    private void refreshStatus() {
        status.setText(AutoBackup.isEnabled(this) ? "Google Drive مفعّل للنسخ التلقائي" : "غير متصل بـ Google Drive");
    }
    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); refreshStatus(); }
    @Override protected void onDestroy() { super.onDestroy(); io.shutdown(); }
}
