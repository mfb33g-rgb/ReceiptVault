package com.adam.receiptvault;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {
    private ReceiptDbHelper db;
    private EditText search;
    private ListView list;
    private TextView summary;
    private final List<Receipt> items = new ArrayList<>();
    private ArrayAdapter<Receipt> adapter;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        db = new ReceiptDbHelper(this);
        search = findViewById(R.id.editSearch);
        list = findViewById(R.id.listReceipts);
        summary = findViewById(R.id.txtSummary);
        Button add = findViewById(R.id.btnAdd);
        Button drive = findViewById(R.id.btnDrive);

        adapter = new ArrayAdapter<Receipt>(this, android.R.layout.simple_list_item_2, android.R.id.text1, items) {
            @Override public View getView(int position, View convertView, ViewGroup parent) {
                View v = super.getView(position, convertView, parent);
                TextView t1 = v.findViewById(android.R.id.text1);
                TextView t2 = v.findViewById(android.R.id.text2);
                Receipt r = getItem(position);
                String merchant = (r.merchant == null || r.merchant.isEmpty()) ? "بدون اسم" : r.merchant;
                t1.setText(merchant + "   $" + String.format(Locale.US, "%.2f", r.total));
                t2.setText((r.date == null ? "" : r.date) + "   •   " + (r.category == null ? "أخرى" : r.category));
                t1.setTextDirection(View.TEXT_DIRECTION_RTL);
                t2.setTextDirection(View.TEXT_DIRECTION_RTL);
                return v;
            }
        };
        list.setAdapter(adapter);
        list.setOnItemClickListener((parent, view, position, id) -> {
            Intent i = new Intent(this, ReceiptReviewActivity.class);
            i.putExtra("receipt_id", items.get(position).id);
            startActivity(i);
        });

        add.setOnClickListener(v -> startActivity(new Intent(this, CaptureActivity.class)));
        drive.setOnClickListener(v -> startActivity(new Intent(this, DriveSettingsActivity.class)));

        search.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            public void onTextChanged(CharSequence s, int start, int before, int count) { reload(); }
            public void afterTextChanged(Editable s) {}
        });
    }

    @Override protected void onResume() {
        super.onResume();
        reload();
    }

    private void reload() {
        if (db == null || search == null) return;
        items.clear();
        items.addAll(db.search(search.getText().toString()));
        adapter.notifyDataSetChanged();
        summary.setText(db.count() + " وصولات محفوظة");
    }
}
