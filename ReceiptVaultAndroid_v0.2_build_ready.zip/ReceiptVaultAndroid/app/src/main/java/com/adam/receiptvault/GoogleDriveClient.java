package com.adam.receiptvault;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public final class GoogleDriveClient {
    private static final String API = "https://www.googleapis.com/drive/v3/files";
    private static final String UPLOAD = "https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart";
    private GoogleDriveClient() {}

    public static String uploadBackup(String accessToken, File zip) throws Exception {
        String boundary = "ReceiptVaultBoundary" + System.currentTimeMillis();
        HttpURLConnection c = (HttpURLConnection) new URL(UPLOAD).openConnection();
        c.setRequestMethod("POST");
        c.setDoOutput(true);
        c.setChunkedStreamingMode(1024 * 1024);
        c.setRequestProperty("Authorization", "Bearer " + accessToken);
        c.setRequestProperty("Content-Type", "multipart/related; boundary=" + boundary);

        JSONObject metadata = new JSONObject();
        metadata.put("name", zip.getName());
        metadata.put("parents", new JSONArray().put("appDataFolder"));
        try (OutputStream out = new BufferedOutputStream(c.getOutputStream());
             InputStream in = new BufferedInputStream(new java.io.FileInputStream(zip))) {
            write(out, "--" + boundary + "\r\n");
            write(out, "Content-Type: application/json; charset=UTF-8\r\n\r\n");
            write(out, metadata.toString());
            write(out, "\r\n--" + boundary + "\r\n");
            write(out, "Content-Type: application/zip\r\n\r\n");
            byte[] buf = new byte[64 * 1024];
            int n;
            while ((n = in.read(buf)) >= 0) out.write(buf, 0, n);
            write(out, "\r\n--" + boundary + "--\r\n");
        }
        String body = readResponse(c);
        if (c.getResponseCode() / 100 != 2) throw new IllegalStateException("Drive upload failed: " + c.getResponseCode() + " " + body);
        return new JSONObject(body).optString("id");
    }

    public static DriveFile latestBackup(String accessToken) throws Exception {
        List<DriveFile> files = listBackups(accessToken);
        return files.isEmpty() ? null : files.get(0);
    }

    public static List<DriveFile> listBackups(String accessToken) throws Exception {
        String q = "name contains 'receiptvault_backup_' and trashed = false";
        String url = API + "?spaces=appDataFolder&q=" + URLEncoder.encode(q, "UTF-8") +
                "&orderBy=modifiedTime desc&fields=files(id,name,modifiedTime,size)&pageSize=100";
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setRequestProperty("Authorization", "Bearer " + accessToken);
        String body = readResponse(c);
        if (c.getResponseCode() / 100 != 2) throw new IllegalStateException("Drive list failed: " + c.getResponseCode() + " " + body);
        JSONArray arr = new JSONObject(body).optJSONArray("files");
        List<DriveFile> out = new ArrayList<>();
        if (arr != null) {
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                out.add(new DriveFile(o.optString("id"), o.optString("name"), o.optString("modifiedTime"), o.optLong("size")));
            }
        }
        out.sort(Comparator.comparing((DriveFile f) -> f.modifiedTime).reversed());
        return out;
    }

    public static File download(String accessToken, DriveFile file, File destination) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(API + "/" + file.id + "?alt=media").openConnection();
        c.setRequestProperty("Authorization", "Bearer " + accessToken);
        if (c.getResponseCode() / 100 != 2) throw new IllegalStateException("Drive download failed: " + c.getResponseCode());
        try (InputStream in = new BufferedInputStream(c.getInputStream());
             OutputStream out = new BufferedOutputStream(new FileOutputStream(destination))) {
            byte[] buf = new byte[64 * 1024];
            int n; while ((n = in.read(buf)) >= 0) out.write(buf, 0, n);
        }
        return destination;
    }

    public static void keepLatest(String accessToken, int keep) throws Exception {
        List<DriveFile> files = listBackups(accessToken);
        for (int i = keep; i < files.size(); i++) delete(accessToken, files.get(i).id);
    }

    public static void delete(String accessToken, String id) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(API + "/" + id).openConnection();
        c.setRequestMethod("DELETE");
        c.setRequestProperty("Authorization", "Bearer " + accessToken);
        int code = c.getResponseCode();
        if (code / 100 != 2 && code != 404) throw new IllegalStateException("Drive delete failed: " + code);
        c.disconnect();
    }

    private static void write(OutputStream out, String s) throws Exception { out.write(s.getBytes(StandardCharsets.UTF_8)); }
    private static String readResponse(HttpURLConnection c) throws Exception {
        InputStream in = c.getResponseCode() / 100 == 2 ? c.getInputStream() : c.getErrorStream();
        if (in == null) return "";
        try (InputStream x = in; java.io.ByteArrayOutputStream bos = new java.io.ByteArrayOutputStream()) {
            byte[] buf = new byte[8192]; int n;
            while ((n = x.read(buf)) >= 0) bos.write(buf, 0, n);
            return bos.toString(StandardCharsets.UTF_8.name());
        }
    }

    public static class DriveFile {
        public final String id, name, modifiedTime; public final long size;
        public DriveFile(String id, String name, String modifiedTime, long size) {
            this.id=id; this.name=name; this.modifiedTime=modifiedTime; this.size=size;
        }
    }
}
