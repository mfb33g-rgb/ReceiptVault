package com.adam.receiptvault;

public class Receipt {
    public long id;
    public String merchant = "";
    public String date = "";
    public double total = 0.0;
    public double tax = 0.0;
    public String category = "أخرى";
    public String invoice = "";
    public String paymentMethod = "";
    public String address = "";
    public double gallons = 0.0;
    public double unitPrice = 0.0;
    public String notes = "";
    public String rawText = "";
    public String imagePath = "";
    public long createdAt = System.currentTimeMillis();
}
