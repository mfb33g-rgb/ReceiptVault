package com.adam.receiptvault;

import android.content.Context;

import androidx.work.Constraints;
import androidx.work.ExistingPeriodicWorkPolicy;
import androidx.work.NetworkType;
import androidx.work.OneTimeWorkRequest;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;

import java.util.concurrent.TimeUnit;

public final class AutoBackup {
    private AutoBackup() {}
    public static final String PREFS = "receiptvault_prefs";
    public static final String KEY_DRIVE_ENABLED = "drive_enabled";

    public static boolean isEnabled(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_DRIVE_ENABLED, false);
    }

    public static void setEnabled(Context context, boolean enabled) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY_DRIVE_ENABLED, enabled).apply();
    }

    private static Constraints anyInternet() {
        // Deliberately CONNECTED, not UNMETERED: mobile data (4G/5G) is allowed.
        return new Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build();
    }

    public static void scheduleDaily(Context context) {
        if (!isEnabled(context)) return;
        PeriodicWorkRequest req = new PeriodicWorkRequest.Builder(BackupWorker.class, 24, TimeUnit.HOURS)
                .setConstraints(anyInternet()).build();
        WorkManager.getInstance(context).enqueueUniquePeriodicWork("receiptvault_daily_backup", ExistingPeriodicWorkPolicy.UPDATE, req);
    }

    public static void scheduleAfterSave(Context context) {
        if (!isEnabled(context)) return;
        OneTimeWorkRequest req = new OneTimeWorkRequest.Builder(BackupWorker.class).setConstraints(anyInternet()).build();
        WorkManager.getInstance(context).enqueue(req);
    }
}
