package com.adam.receiptvault;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

import com.google.android.gms.auth.api.identity.AuthorizationResult;
import com.google.android.gms.tasks.Tasks;

import java.io.File;

public class BackupWorker extends Worker {
    public BackupWorker(@NonNull Context context, @NonNull WorkerParameters params) { super(context, params); }

    @NonNull @Override public Result doWork() {
        try {
            if (!AutoBackup.isEnabled(getApplicationContext())) return Result.success();
            AuthorizationResult auth = Tasks.await(DriveAuth.authorize(getApplicationContext()));
            if (auth.hasResolution() || auth.getAccessToken() == null) return Result.retry();
            File zip = BackupArchive.create(getApplicationContext());
            GoogleDriveClient.uploadBackup(auth.getAccessToken(), zip);
            GoogleDriveClient.keepLatest(auth.getAccessToken(), 10);
            return Result.success();
        } catch (Exception e) {
            return Result.retry();
        }
    }
}
