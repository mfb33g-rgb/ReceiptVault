package com.adam.receiptvault;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

public final class BackupArchive {
    private BackupArchive() {}

    public static File create(Context context) throws Exception {
        ReceiptDbHelper db = new ReceiptDbHelper(context);
        File outDir = new File(context.getCacheDir(), "backup_out");
        if (!outDir.exists()) outDir.mkdirs();
        String stamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
        File zip = new File(outDir, "receiptvault_backup_" + stamp + ".zip");

        JSONArray data = db.exportJson();
        JSONObject root = new JSONObject();
        root.put("version", 1);
        root.put("createdAt", System.currentTimeMillis());
        root.put("receipts", data);

        try (ZipOutputStream zos = new ZipOutputStream(new BufferedOutputStream(new FileOutputStream(zip)))) {
            zos.putNextEntry(new ZipEntry("receipts.json"));
            zos.write(root.toString().getBytes(StandardCharsets.UTF_8));
            zos.closeEntry();

            Map<String, Boolean> added = new HashMap<>();
            for (int i = 0; i < data.length(); i++) {
                JSONObject o = data.getJSONObject(i);
                String path = o.optString("imagePath", "");
                if (path.isEmpty()) continue;
                File image = new File(path);
                if (!image.exists() || added.containsKey(image.getName())) continue;
                added.put(image.getName(), true);
                zos.putNextEntry(new ZipEntry("images/" + image.getName()));
                try (BufferedInputStream in = new BufferedInputStream(new FileInputStream(image))) {
                    byte[] buf = new byte[64 * 1024];
                    int n;
                    while ((n = in.read(buf)) >= 0) zos.write(buf, 0, n);
                }
                zos.closeEntry();
            }
        }
        return zip;
    }

    public static void restore(Context context, File zip) throws Exception {
        File receiptsDir = new File(context.getFilesDir(), "receipts");
        if (!receiptsDir.exists()) receiptsDir.mkdirs();
        String json = null;
        Map<String, String> restoredPaths = new HashMap<>();

        try (ZipInputStream zis = new ZipInputStream(new BufferedInputStream(new FileInputStream(zip)))) {
            ZipEntry entry;
            byte[] buf = new byte[64 * 1024];
            while ((entry = zis.getNextEntry()) != null) {
                String name = entry.getName();
                if ("receipts.json".equals(name)) {
                    ByteArrayOutputStream bos = new ByteArrayOutputStream();
                    int n;
                    while ((n = zis.read(buf)) >= 0) bos.write(buf, 0, n);
                    json = bos.toString(StandardCharsets.UTF_8.name());
                } else if (name.startsWith("images/") && !entry.isDirectory()) {
                    String base = new File(name).getName();
                    File out = new File(receiptsDir, base);
                    try (BufferedOutputStream fos = new BufferedOutputStream(new FileOutputStream(out))) {
                        int n;
                        while ((n = zis.read(buf)) >= 0) fos.write(buf, 0, n);
                    }
                    restoredPaths.put(base, out.getAbsolutePath());
                }
                zis.closeEntry();
            }
        }
        if (json == null) throw new IllegalStateException("Backup does not contain receipts.json");
        JSONObject root = new JSONObject(json);
        JSONArray arr = root.getJSONArray("receipts");
        for (int i = 0; i < arr.length(); i++) {
            JSONObject o = arr.getJSONObject(i);
            String oldPath = o.optString("imagePath", "");
            String base = oldPath.isEmpty() ? "" : new File(oldPath).getName();
            if (!base.isEmpty() && restoredPaths.containsKey(base)) o.put("imagePath", restoredPaths.get(base));
        }
        new ReceiptDbHelper(context).replaceFromJson(arr);
    }
}
