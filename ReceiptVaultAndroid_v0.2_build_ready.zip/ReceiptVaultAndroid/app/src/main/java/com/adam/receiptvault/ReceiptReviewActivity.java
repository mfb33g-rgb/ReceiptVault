package com.adam.receiptvault;

import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Arrays;
import java.util.List;

public class ReceiptReviewActivity extends AppCompatActivity {
    private static final List<String> CATEGORIES = Arrays.asList(
            "ديزل / وقود", "صيانة / تصليح", "قطع غيار", "Toll / رسوم طريق", "تأمين",
            "مواقف", "فندق / سكن", "طعام", "مستلزمات", "دفعة / مدفوعات", "أخرى"
    );

    private ReceiptDbHelper db;
    private Receipt receipt;
    private EditText merchant, date, total, tax, invoice, payment, address, gallons, unitPrice, notes;
    private Spinner category;
    private ImageView image;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_receipt_review);
        db = new ReceiptDbHelper(this);
        bindViews();
        category.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, CATEGORIES));

        long id = getIntent().getLongExtra("receipt_id", 0);
        if (id > 0) receipt = db.get(id);
        if (receipt == null) receipt = fromIntent();
        fill(receipt);

        Button save = findViewById(R.id.btnSave);
        save.setOnClickListener(v -> saveReceipt());
    }

    private void bindViews() {
        image=findViewById(R.id.imageReceipt); merchant=findViewById(R.id.editMerchant); date=findViewById(R.id.editDate);
        total=findViewById(R.id.editTotal); tax=findViewById(R.id.editTax); category=findViewById(R.id.spinnerCategory);
        invoice=findViewById(R.id.editInvoice); payment=findViewById(R.id.editPayment); address=findViewById(R.id.editAddress);
        gallons=findViewById(R.id.editGallons); unitPrice=findViewById(R.id.editUnitPrice); notes=findViewById(R.id.editNotes);
    }

    private Receipt fromIntent() {
        Receipt r = new Receipt();
        r.imagePath=getIntent().getStringExtra("image_path"); if (r.imagePath == null) r.imagePath="";
        r.rawText=getIntent().getStringExtra("raw_text"); if (r.rawText == null) r.rawText="";
        r.merchant=getIntent().getStringExtra("merchant"); if (r.merchant == null) r.merchant="";
        r.date=getIntent().getStringExtra("date"); if (r.date == null) r.date="";
        r.total=getIntent().getDoubleExtra("total",0); r.tax=getIntent().getDoubleExtra("tax",0);
        r.category=getIntent().getStringExtra("category"); if (r.category == null) r.category="أخرى";
        r.invoice=getIntent().getStringExtra("invoice"); if (r.invoice == null) r.invoice="";
        r.paymentMethod=getIntent().getStringExtra("payment"); if (r.paymentMethod == null) r.paymentMethod="";
        r.address=getIntent().getStringExtra("address"); if (r.address == null) r.address="";
        r.gallons=getIntent().getDoubleExtra("gallons",0); r.unitPrice=getIntent().getDoubleExtra("unit_price",0);
        return r;
    }

    private void fill(Receipt r) {
        if (!r.imagePath.isEmpty()) image.setImageBitmap(BitmapFactory.decodeFile(r.imagePath));
        merchant.setText(r.merchant); date.setText(r.date); total.setText(r.total > 0 ? trim(r.total) : "");
        tax.setText(r.tax > 0 ? trim(r.tax) : ""); invoice.setText(r.invoice); payment.setText(r.paymentMethod);
        address.setText(r.address); gallons.setText(r.gallons > 0 ? trim(r.gallons) : "");
        unitPrice.setText(r.unitPrice > 0 ? trim(r.unitPrice) : ""); notes.setText(r.notes);
        int p=CATEGORIES.indexOf(r.category); category.setSelection(p >= 0 ? p : CATEGORIES.size()-1);
    }

    private void saveReceipt() {
        receipt.merchant=merchant.getText().toString().trim(); receipt.date=date.getText().toString().trim();
        receipt.total=num(total); receipt.tax=num(tax); receipt.category=String.valueOf(category.getSelectedItem());
        receipt.invoice=invoice.getText().toString().trim(); receipt.paymentMethod=payment.getText().toString().trim();
        receipt.address=address.getText().toString().trim(); receipt.gallons=num(gallons); receipt.unitPrice=num(unitPrice);
        receipt.notes=notes.getText().toString().trim();
        receipt.id=db.save(receipt);
        AutoBackup.scheduleAfterSave(this);
        Toast.makeText(this, "تم حفظ الوصل", Toast.LENGTH_SHORT).show();
        finish();
    }

    private double num(EditText e) {
        try { return Double.parseDouble(e.getText().toString().replace(",", "").trim()); }
        catch (Exception ex) { return 0.0; }
    }
    private String trim(double v) { return java.math.BigDecimal.valueOf(v).stripTrailingZeros().toPlainString(); }
}
