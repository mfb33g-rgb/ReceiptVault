package com.adam.receiptvault;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class ReceiptDbHelper extends SQLiteOpenHelper {
    private static final String DB_NAME = "receipts.db";
    private static final int DB_VERSION = 1;

    public ReceiptDbHelper(Context context) { super(context, DB_NAME, null, DB_VERSION); }

    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE receipts (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "merchant TEXT,date TEXT,total REAL,tax REAL,category TEXT,invoice TEXT," +
                "payment_method TEXT,address TEXT,gallons REAL,unit_price REAL,notes TEXT," +
                "raw_text TEXT,image_path TEXT,created_at INTEGER)");
        db.execSQL("CREATE INDEX idx_receipts_date ON receipts(date)");
        db.execSQL("CREATE INDEX idx_receipts_category ON receipts(category)");
        db.execSQL("CREATE INDEX idx_receipts_merchant ON receipts(merchant)");
    }

    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {}

    public long save(Receipt r) {
        ContentValues v = toValues(r);
        if (r.id > 0) {
            getWritableDatabase().update("receipts", v, "id=?", new String[]{String.valueOf(r.id)});
            return r.id;
        }
        return getWritableDatabase().insert("receipts", null, v);
    }

    public Receipt get(long id) {
        Cursor c = getReadableDatabase().query("receipts", null, "id=?", new String[]{String.valueOf(id)}, null, null, null);
        try { return c.moveToFirst() ? fromCursor(c) : null; }
        finally { c.close(); }
    }

    public List<Receipt> search(String query) {
        String q = query == null ? "" : query.trim();
        Cursor c;
        if (q.isEmpty()) {
            c = getReadableDatabase().query("receipts", null, null, null, null, null, "created_at DESC");
        } else {
            String like = "%" + q + "%";
            c = getReadableDatabase().query("receipts", null,
                    "merchant LIKE ? OR date LIKE ? OR category LIKE ? OR invoice LIKE ? OR CAST(total AS TEXT) LIKE ?",
                    new String[]{like, like, like, like, like}, null, null, "created_at DESC");
        }
        List<Receipt> out = new ArrayList<>();
        try { while (c.moveToNext()) out.add(fromCursor(c)); }
        finally { c.close(); }
        return out;
    }

    public int count() {
        Cursor c = getReadableDatabase().rawQuery("SELECT COUNT(*) FROM receipts", null);
        try { return c.moveToFirst() ? c.getInt(0) : 0; }
        finally { c.close(); }
    }

    public JSONArray exportJson() throws Exception {
        JSONArray arr = new JSONArray();
        Cursor c = getReadableDatabase().query("receipts", null, null, null, null, null, "id ASC");
        try {
            while (c.moveToNext()) {
                Receipt r = fromCursor(c);
                JSONObject o = new JSONObject();
                o.put("id", r.id); o.put("merchant", r.merchant); o.put("date", r.date);
                o.put("total", r.total); o.put("tax", r.tax); o.put("category", r.category);
                o.put("invoice", r.invoice); o.put("paymentMethod", r.paymentMethod); o.put("address", r.address);
                o.put("gallons", r.gallons); o.put("unitPrice", r.unitPrice); o.put("notes", r.notes);
                o.put("rawText", r.rawText); o.put("imagePath", r.imagePath); o.put("createdAt", r.createdAt);
                arr.put(o);
            }
        } finally { c.close(); }
        return arr;
    }

    public void replaceFromJson(JSONArray arr) throws Exception {
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            db.delete("receipts", null, null);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                Receipt r = new Receipt();
                r.merchant=o.optString("merchant"); r.date=o.optString("date"); r.total=o.optDouble("total");
                r.tax=o.optDouble("tax"); r.category=o.optString("category","أخرى"); r.invoice=o.optString("invoice");
                r.paymentMethod=o.optString("paymentMethod"); r.address=o.optString("address"); r.gallons=o.optDouble("gallons");
                r.unitPrice=o.optDouble("unitPrice"); r.notes=o.optString("notes"); r.rawText=o.optString("rawText");
                r.imagePath=o.optString("imagePath"); r.createdAt=o.optLong("createdAt", System.currentTimeMillis());
                db.insert("receipts", null, toValues(r));
            }
            db.setTransactionSuccessful();
        } finally { db.endTransaction(); }
    }

    private ContentValues toValues(Receipt r) {
        ContentValues v = new ContentValues();
        v.put("merchant", r.merchant); v.put("date", r.date); v.put("total", r.total); v.put("tax", r.tax);
        v.put("category", r.category); v.put("invoice", r.invoice); v.put("payment_method", r.paymentMethod);
        v.put("address", r.address); v.put("gallons", r.gallons); v.put("unit_price", r.unitPrice);
        v.put("notes", r.notes); v.put("raw_text", r.rawText); v.put("image_path", r.imagePath); v.put("created_at", r.createdAt);
        return v;
    }

    private Receipt fromCursor(Cursor c) {
        Receipt r = new Receipt();
        r.id = c.getLong(c.getColumnIndexOrThrow("id"));
        r.merchant = c.getString(c.getColumnIndexOrThrow("merchant"));
        r.date = c.getString(c.getColumnIndexOrThrow("date"));
        r.total = c.getDouble(c.getColumnIndexOrThrow("total"));
        r.tax = c.getDouble(c.getColumnIndexOrThrow("tax"));
        r.category = c.getString(c.getColumnIndexOrThrow("category"));
        r.invoice = c.getString(c.getColumnIndexOrThrow("invoice"));
        r.paymentMethod = c.getString(c.getColumnIndexOrThrow("payment_method"));
        r.address = c.getString(c.getColumnIndexOrThrow("address"));
        r.gallons = c.getDouble(c.getColumnIndexOrThrow("gallons"));
        r.unitPrice = c.getDouble(c.getColumnIndexOrThrow("unit_price"));
        r.notes = c.getString(c.getColumnIndexOrThrow("notes"));
        r.rawText = c.getString(c.getColumnIndexOrThrow("raw_text"));
        r.imagePath = c.getString(c.getColumnIndexOrThrow("image_path"));
        r.createdAt = c.getLong(c.getColumnIndexOrThrow("created_at"));
        return r;
    }
}
