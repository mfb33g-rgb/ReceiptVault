package com.adam.receiptvault;

import org.junit.Test;
import static org.junit.Assert.*;

public class ReceiptParserTest {
    @Test public void parsesFuelReceipt() {
        String text = "RaceTrac #2652\n11500 County Rd 99\n08/22/2026 09:49 AM\nDiesel\n191.133 gallons\nPrice/Gal $4.989\nTOTAL $953.56\nVisa";
        Receipt r = ReceiptParser.parse(text);
        assertEquals(953.56, r.total, 0.001);
        assertEquals(191.133, r.gallons, 0.001);
        assertEquals(4.989, r.unitPrice, 0.001);
        assertEquals("ديزل / وقود", r.category);
    }

    @Test public void parsesRepairInvoice() {
        String text = "MACK SERVICE CENTER\nInvoice #A12345\n09/25/2026\nLabor $450.00\nParts $315.25\nSales Tax $18.91\nGrand Total $784.16\nCredit Card";
        Receipt r = ReceiptParser.parse(text);
        assertEquals(784.16, r.total, 0.001);
        assertEquals(18.91, r.tax, 0.001);
        assertEquals("صيانة / تصليح", r.category);
        assertEquals("A12345", r.invoice);
    }
}
